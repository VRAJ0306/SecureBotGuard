#!/bin/bash
uvicorn app.main:app --reload
